package com.tirupati.ilauncher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LauncherApp() }
    }
}

private data class AppTile(val name: String, val icon: ImageVector, val color: Color)
private val appTiles = listOf(
    AppTile("Phone", Icons.Default.Call, Color(0xFF35C96F)),
    AppTile("Messages", Icons.Default.ChatBubble, Color(0xFF32C875)),
    AppTile("Photos", Icons.Default.Collections, Color(0xFFFF7A9E)),
    AppTile("Camera", Icons.Default.CameraAlt, Color(0xFF333640)),
    AppTile("Calendar", Icons.Default.CalendarMonth, Color(0xFFF4F5F7)),
    AppTile("Clock", Icons.Default.AccessTime, Color(0xFF262B34)),
    AppTile("Maps", Icons.Default.Map, Color(0xFF42A5F5)),
    AppTile("Music", Icons.Default.MusicNote, Color(0xFFFF4F76)),
    AppTile("Mail", Icons.Default.Email, Color(0xFF4C9DFF)),
    AppTile("Weather", Icons.Default.WbSunny, Color(0xFF49B9F3)),
    AppTile("Settings", Icons.Default.Settings, Color(0xFF858B96)),
    AppTile("Store", Icons.Default.ShoppingBag, Color(0xFF7D65F5))
)

@Composable
private fun LauncherApp() {
    var clockStyle by remember { mutableIntStateOf(0) }
    var islandMode by remember { mutableIntStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }
    var showLibrary by remember { mutableStateOf(false) }
    var theme by remember { mutableIntStateOf(0) } // 0 auto/color, 1 light, 2 dark
    val dark = theme == 2
    val bg = if (dark) Color(0xFF080D19) else Color(0xFF0D284E)
    val fg = Color.White
    val gradient = Brush.linearGradient(
        listOf(Color(0xFF1376C8), Color(0xFF7354A8), Color(0xFFFFA66C), Color(0xFF153A66))
    )
    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Box(Modifier.fillMaxSize().background(gradient)) {
            // Ambient wallpaper-like shapes
            Box(Modifier.fillMaxWidth().fillMaxHeight(.56f).align(Alignment.BottomCenter)
                .background(Brush.verticalGradient(listOf(Color.Transparent, bg.copy(alpha = .75f)))))
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(SimpleDateFormat("h:mm", Locale.getDefault()).format(Date()), color = fg, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    DynamicIsland(mode = islandMode, onClick = { islandMode = (islandMode + 1) % 5 })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.SignalCellularAlt, null, tint = fg, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(3.dp))
                        Icon(Icons.Default.Wifi, null, tint = fg, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(3.dp))
                        Icon(Icons.Default.BatteryFull, null, tint = fg, modifier = Modifier.size(17.dp))
                    }
                }
                Spacer(Modifier.height(34.dp))
                ClockFace(clockStyle, fg)
                Spacer(Modifier.height(24.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MiniWidget("WEATHER", "28°", "Sunny", Icons.Default.WbSunny)
                    MiniWidget("CALENDAR", SimpleDateFormat("EEE, d", Locale.getDefault()).format(Date()), "No events today", Icons.Default.CalendarMonth)
                }
                Spacer(Modifier.height(22.dp))
                if (showSettings) {
                    SettingsPanel(
                        clockStyle = clockStyle, onClock = { clockStyle = it },
                        theme = theme, onTheme = { theme = it },
                        islandMode = islandMode, onIsland = { islandMode = it },
                        onClose = { showSettings = false }
                    )
                } else if (showLibrary) {
                    Text("App Library", color = fg, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(appTiles) { AppIcon(it) }
                    }
                    TextButton(onClick = { showLibrary = false }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Home", color = fg) }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(18.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) { items(appTiles.take(8)) { AppIcon(it) } }
                    TextButton(onClick = { showLibrary = true }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                        Icon(Icons.Default.Search, null, tint = fg)
                        Text(" Search", color = fg)
                    }
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp))
                            .background(Color.White.copy(alpha = .20f)).padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        appTiles.take(4).forEach { AppIcon(it, dock = true) }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("iLauncher", color = fg.copy(alpha = .8f), fontSize = 11.sp)
                        TextButton(onClick = { showSettings = true }) { Icon(Icons.Default.Tune, null, tint = fg); Text(" Customize", color = fg) }
                    }
                }
            }
        }
    }
}

@Composable
private fun DynamicIsland(mode: Int, onClick: () -> Unit) {
    val labels = listOf(" ", "☎  Call 00:12", "♫  Now Playing", "➤  Navigation", "⚡  Charging 78%")
    Row(
        Modifier.widthIn(min = 86.dp, max = 190.dp).clip(CircleShape)
            .background(Color.Black).clickable { onClick() }.padding(horizontal = 15.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        if (mode == 0) {
            Box(Modifier.width(48.dp).height(13.dp).clip(CircleShape).background(Color.Black))
        } else {
            Text(labels[mode], color = Color.White, fontSize = 10.sp, maxLines = 1)
        }
    }
}

@Composable
private fun ClockFace(style: Int, color: Color) {
    val time = SimpleDateFormat("h:mm", Locale.getDefault()).format(Date())
    val date = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date())
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(date, color = color.copy(alpha = .9f), fontSize = 13.sp)
        Spacer(Modifier.height(3.dp))
        when (style) {
            0 -> Text(time, color = color, fontSize = 62.sp, fontWeight = FontWeight.Light)
            1 -> Text(time, color = color, fontSize = 66.sp, fontWeight = FontWeight.Black)
            2 -> Text(time, color = Color(0xFFB7E5FF), fontSize = 60.sp, fontWeight = FontWeight.Thin)
            3 -> Box(Modifier.size(108.dp).clip(CircleShape).background(Color.White.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                Text("◷", color = color, fontSize = 76.sp)
            }
            4 -> Text(time, color = color, fontSize = 54.sp, fontWeight = FontWeight.Light)
            else -> Text(time, fontSize = 62.sp, fontWeight = FontWeight.ExtraBold,
                color = Color(0xFFFFA7C5))
        }
    }
}

@Composable
private fun MiniWidget(title: String, main: String, subtitle: String, icon: ImageVector) {
    Column(Modifier.width(145.dp).clip(RoundedCornerShape(22.dp))
        .background(Color.White.copy(alpha = .20f)).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(5.dp))
            Text(title, color = Color.White.copy(alpha = .85f), fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
        Text(main, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Medium)
        Text(subtitle, color = Color.White, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
private fun AppIcon(tile: AppTile, dock: Boolean = false) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(vertical = 2.dp)) {
        Box(Modifier.size(if (dock) 48.dp else 56.dp).clip(RoundedCornerShape(16.dp))
            .background(tile.color), contentAlignment = Alignment.Center) {
            Icon(tile.icon, contentDescription = tile.name, tint = if (tile.name == "Calendar") Color(0xFF303744) else Color.White, modifier = Modifier.size(29.dp))
        }
        if (!dock) {
            Spacer(Modifier.height(5.dp))
            Text(tile.name, color = Color.White, fontSize = 10.sp, textAlign = TextAlign.Center, maxLines = 1)
        }
    }
}

@Composable
private fun SettingsPanel(
    clockStyle: Int, onClock: (Int) -> Unit, theme: Int, onTheme: (Int) -> Unit,
    islandMode: Int, onIsland: (Int) -> Unit, onClose: () -> Unit
) {
    Column(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(24.dp))
        .background(Color(0xE8151C2B)).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Customize", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            TextButton(onClick = onClose) { Text("Done", color = Color(0xFF8ECFFF)) }
        }
        Text("CLOCK STYLE", color = Color.LightGray, fontSize = 11.sp)
        val styles = listOf("Default", "Bold", "Digital", "Analog", "Minimal", "Color")
        styles.forEachIndexed { index, label ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                .clickable { onClock(index) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(label, color = Color.White, modifier = Modifier.weight(1f))
                if (clockStyle == index) Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF70D6A5))
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("APPEARANCE", color = Color.LightGray, fontSize = 11.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Auto", "Light", "Dark").forEachIndexed { i, s ->
                FilterChip(selected = theme == i, onClick = { onTheme(i) }, label = { Text(s) })
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("DYNAMIC ISLAND DEMO", color = Color.LightGray, fontSize = 11.sp)
        listOf("Off", "Call", "Music", "Navigation", "Charging").forEachIndexed { i, s ->
            TextButton(onClick = { onIsland(i) }) { Text(s, color = Color.White) }
        }
    }
}
