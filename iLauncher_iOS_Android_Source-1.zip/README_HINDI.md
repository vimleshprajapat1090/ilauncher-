# iLauncher — iOS-inspired Android Launcher

यह Android Studio/Kotlin + Jetpack Compose का शुरुआती प्रोजेक्ट है। यह iPhone/iOS का वास्तविक सिस्टम नहीं है; Android पर iOS-जैसा home screen UI देता है।

## शामिल
- Home screen और ऐप-जैसे आइकन
- 6 clock styles: Default, Bold, Digital outline, Analog-inspired, Minimal, Color
- Light/Dark/Auto appearance selector
- Dynamic Island-जैसी UI pill: tap करके Call / Music / Navigation / Charging / Notification demo बदलें
- ऐप सूची खोलने का बटन
- Android launcher के रूप में चुनने की manifest activity

## ज़रूरी बातें
- Dynamic Island demo UI है; असली कॉल/मीडिया/नेविगेशन की लाइव जानकारी के लिए Android notification/media-session integrations, permissions और device testing जोड़नी होगी।
- किसी launcher को Android status bar/lock screen का पूर्ण नियंत्रण नहीं मिलता। वास्तविक lock-screen replacement सामान्य launcher permission से संभव नहीं है।
- यह प्रोजेक्ट source ZIP है, APK नहीं। इस वातावरण में Android SDK/Gradle build उपलब्ध न होने के कारण signed/installed APK compile नहीं किया गया।

## Build (PC या cloud Android build environment)
1. Android Studio में `iLauncher_iOS_Android` folder खोलें।
2. Gradle sync होने दें।
3. Build > Build APK(s) चुनें।
4. Debug APK: `app/build/outputs/apk/debug/app-debug.apk`

## Android मोबाइल से
मोबाइल पर Android Studio आधिकारिक रूप से उपलब्ध नहीं है। AndroidIDE जैसे IDE में project खोलने की कोशिश कर सकते हैं, लेकिन Gradle/SDK compatibility पर निर्भर करेगा। आसान विकल्प किसी PC या cloud build service से APK बनाना है।
